import type { Font } from '@pdfme/common';

/**
 * Font configuration for pdfme
 * Uses local Node server at http://localhost:3001
 * Fonts are stored in storage/fonts directory
 * For UI preview, uses Google Fonts for browser rendering
 */

export const fontConfig: Font = {
  Montserrat: {
    data: 'http://localhost:3001/fonts/Montserrat-Regular.ttf',
    fallback: true,
  },
  'Montserrat-Bold': {
    data: 'http://localhost:3001/fonts/Montserrat-Bold.ttf',
  },
  'Montserrat-Italic': {
    data: 'http://localhost:3001/fonts/Montserrat-MediumItalic.ttf',
  },
};

/**
 * Font options for UI preview (Designer, Form, Viewer)
 * Uses Google Fonts for browser rendering
 */
export const uiFontOptions = {
  fonts: [
    { name: 'Montserrat', url: 'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap' }
  ]
};

/**
 * Default font name for text fields
 */
export const DEFAULT_FONT_NAME = 'Montserrat';
